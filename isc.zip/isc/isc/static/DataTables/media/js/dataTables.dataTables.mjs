/*! DataTables styling integration
 * ©2018 SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net';





export default DataTable;
