from django.contrib import admin
from django.urls import path
from . import views

app_name='public'
urlpatterns = [
    # Accueil
    path('',views.index,name='accueil'),
    # Espace de travail
    path('espace/administratif/<int:adm_id>',views.espace_administratif,name='espace_administratif'),
    path('espace/apprenant/<int:apr_id>',views.espace_apprenant,name='espace_apprenant'),
    path('espace/formateur/<int:fmt_id>',views.espace_formateur,name='espace_formateur'),
    # Message d'erreur
    path('message/erreur/',views.msg_erreur,name='msg_erreur'),
]