from django.shortcuts import render, redirect, get_object_or_404,HttpResponse
from django.urls import reverse
from .forms import LoginForm
from administrateur.models import Personne,Administratif,Apprenant,Devoir,Document,Formateur
from django.views.decorators.csrf import csrf_protect

def index(request):
    message = ''
    if request.method == 'POST':
        connexion = LoginForm(request.POST)
        
        if connexion.is_valid():
            donnees = connexion.cleaned_data
            username = donnees['email']
            password = donnees['motDePasse']
            user = Personne.objects.filter(email=username, motDePasse=password).first()
            context = {'form': connexion}
            
            if user is not None and user.id is not None:
                user_grade = user.grade.id
                if user_grade == 1: # si le grade est "administratif" (1)
                    return redirect(reverse('public:espace_administratif', args=[user.id]))
                elif user_grade == 2: # si le grade est "apprenant" (2)
                    return redirect(reverse('public:espace_apprenant', args=[user.id]))
                elif user_grade == 3: # si le grade est "formateur" (3)
                    return redirect(reverse('public:espace_formateur', args=[user.id]))
                else:
                    message = "Grade inconnu."
                    return redirect(reverse('public:msg_erreur') + f'?message={message}')
            else:
                message = 'Identifiant ou mot de passe incorrect.'
                return redirect(reverse('public:msg_erreur') + f'?message={message}')
        else:
            context['form'] = connexion
    else:
        connexion = LoginForm()
    
    return render(request, 'public/index.html', {'form': connexion, 'message': message,})

@csrf_protect
def espace_administratif(request,adm_id):
    administratif=get_object_or_404(Administratif, pk=adm_id)
    context={
        'administratif':administratif,
    }
    return render(request, 'public/administratif.html', context)

@csrf_protect
def espace_apprenant(request,apr_id):
    apprenant=get_object_or_404(Apprenant, pk=apr_id)
    context={
        'apprenant':apprenant,
    }
    return render(request, 'public/apprenant.html', context)

@csrf_protect
def espace_formateur(request,fmt_id):
    formateur=get_object_or_404(Formateur, pk=fmt_id)
    context={
        'formateur':formateur,
    }
    return render(request, 'public/formateur.html', context)
    
def msg_erreur(request):
    return render(request,'public/err_msg.html')
