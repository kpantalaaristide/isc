from django import forms
from administrateur.models import Grade,Document,Classe,Matiere,Personne

class LoginForm(forms.ModelForm):
    class Meta:
        model=Personne
        fields=('email','motDePasse')
        widgets={
            'email': forms.TextInput(),
            'motDePasse': forms.PasswordInput()
        }