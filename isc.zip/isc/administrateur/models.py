from django.db import models
from phonenumber_field.modelfields import PhoneNumberField

class Grade(models.Model):
    libelle = models.CharField(max_length=25)
    def __str__(self):
        return str(self.libelle)

class Personne(models.Model):
    nom = models.CharField(max_length=40)
    prenom = models.CharField(max_length=50)
    contact = PhoneNumberField(region='TG', blank=True, null=True)
    email = models.EmailField()
    motDePasse = models.CharField(max_length=15)
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE)
    def __str__(self):
        return str(self.nom)

class Formateur(models.Model):
    personne = models.OneToOneField(Personne, on_delete=models.CASCADE, primary_key=True,default=0)
    matieres_enseignees = models.ManyToManyField('Matiere')
    def __str__(self):
        return str(self.personne.nom)

class Apprenant(models.Model):
    personne = models.OneToOneField(Personne, on_delete=models.CASCADE, primary_key=True,default=0)
    classe = models.ForeignKey('Classe', on_delete=models.CASCADE)
    matricule = models.CharField(max_length=255)
    def __str__(self):
        return str(self.personne.nom)

class Seance(models.Model):
    formateur = models.ForeignKey('Formateur', on_delete=models.CASCADE)
    titre = models.CharField(max_length=255)
    apprenants = models.ManyToManyField('Apprenant')
    date = models.DateField()
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    duree = models.IntegerField()
    ressources = models.ManyToManyField('Document')
    motif_seance = models.TextField()
    devoir_seance = models.ForeignKey('Devoir', on_delete=models.CASCADE)
    def __str__(self):
        return str(self.titre)

class Devoir(models.Model):
    seance_devoir = models.ForeignKey('Seance', on_delete=models.CASCADE)
    enonce_devoir = models.TextField()
    reponse_devoir = models.TextField()

class Administratif(models.Model):
    personne = models.OneToOneField(Personne, on_delete=models.CASCADE, primary_key=True,default=0)
    def __str__(self):
        return str(self.personne.nom)
    
class Classe(models.Model):
    nom_classe = models.CharField(max_length=255)
    libelle_classe = models.CharField(max_length=255)
    def __str__(self):
        return str(self.nom_classe)

class Matiere(models.Model):
    nom_matiere = models.CharField(max_length=8)
    libelle_matiere = models.CharField(max_length=255)
    def __str__(self):
        return str(self.nom_matiere)

class Document(models.Model):
    fichier = models.FileField(upload_to='documents/')

