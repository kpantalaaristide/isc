from django.contrib import admin
from .models import Administratif,Apprenant,Formateur,Devoir,Seance,Grade,Document,Classe,Matiere,Personne
# Register your models here.
admin.site.register(Administratif)
admin.site.register(Apprenant)
admin.site.register(Formateur)
admin.site.register(Seance)
admin.site.register(Devoir)
admin.site.register(Document)
admin.site.register(Grade)
admin.site.register(Classe)
admin.site.register(Matiere)
admin.site.register(Personne)